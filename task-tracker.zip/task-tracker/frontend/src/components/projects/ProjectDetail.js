// src/components/projects/ProjectDetail.js
import React, { useEffect, useContext, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { Container, Row, Col, Card, Button, Table, Badge, Form } from 'react-bootstrap';
import ProjectContext from '../../context/project/projectContext';
import TaskContext from '../../context/task/taskContext';
import Spinner from '../layout/Spinner';
import TaskItem from '../tasks/TaskItem';

const ProjectDetail = () => {
  const projectContext = useContext(ProjectContext);
  const taskContext = useContext(TaskContext);
  const { id } = useParams();
  const navigate = useNavigate();

  const { getProjectById, project, loading: projectLoading, error } = projectContext;
  const { getTasks, tasks, loading: tasksLoading } = taskContext;

  const [filter, setFilter] = useState('all');

  useEffect(() => {
    getProjectById(id);
    getTasks(id);

    if (error) {
      navigate('/');
    }
    // eslint-disable-next-line
  }, [id, error]);

  const filteredTasks = tasks.filter(task => {
    if (filter === 'all') return true;
    return task.status.toLowerCase() === filter.toLowerCase();
  });

  if (projectLoading || tasksLoading || !project) {
    return <Spinner />;
  }

  const { name, description, createdAt } = project;
  const formattedDate = new Date(createdAt).toLocaleDateString();

  // Calculate task statistics
  const completedTasks = tasks.filter(task => task.status === 'Completed').length;
  const inProgressTasks = tasks.filter(task => task.status === 'In Progress').length;
  const notStartedTasks = tasks.filter(task => task.status === 'Not Started').length;
  const progress = tasks.length > 0 ? Math.round((completedTasks / tasks.length) * 100) : 0;

  return (
    <Container>
      <Row className="mb-4">
        <Col>
          <Button variant="outline-secondary" as={Link} to="/" className="mb-3">
            <i className="fas fa-arrow-left"></i> Back to Dashboard
          </Button>
          <h1>{name}</h1>
          <p className="text-muted">Created on {formattedDate}</p>
          <p>{description}</p>

          <div className="d-flex mb-3">
            <div className="me-3">
              <strong>Progress: </strong>
              <span>{progress}%</span>
            </div>
            <div className="me-3">
              <Badge bg="success">{completedTasks} Completed</Badge>
            </div>
            <div className="me-3">
              <Badge bg="warning">{inProgressTasks} In Progress</Badge>
            </div>
            <div>
              <Badge bg="danger">{notStartedTasks} Not Started</Badge>
            </div>
          </div>

          <div className="progress mb-4" style={{ height: '20px' }}>
            <div
              className="progress-bar bg-success"
              role="progressbar"
              style={{ width: `${completedTasks / tasks.length * 100}%` }}
              aria-valuenow={completedTasks}
              aria-valuemin="0"
              aria-valuemax={tasks.length}
            >
              Completed
            </div>
            <div
              className="progress-bar bg-warning"
              role="progressbar"
              style={{ width: `${inProgressTasks / tasks.length * 100}%` }}
              aria-valuenow={inProgressTasks}
              aria-valuemin="0"
              aria-valuemax={tasks.length}
            >
              In Progress
            </div>
            <div
              className="progress-bar bg-danger"
              role="progressbar"
              style={{ width: `${notStartedTasks / tasks.length * 100}%` }}
              aria-valuenow={notStartedTasks}
              aria-valuemin="0"
              aria-valuemax={tasks.length}
            >
              Not Started
            </div>
          </div>
        </Col>
      </Row>

      <Row className="mb-3 align-items-center">
        <Col>
          <h2>
            <i className="fas fa-list-check"></i> Tasks
          </h2>
        </Col>
        <Col xs="auto">
          <Link to={`/projects/${id}/tasks/create`}>
            <Button variant="primary">
              <i className="fas fa-plus"></i> Add Task
            </Button>
          </Link>
        </Col>
      </Row>

      <Row className="mb-3">
        <Col>
          <Form.Group>
            <Form.Label>Filter by Status:</Form.Label>
            <Form.Select 
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
            >
              <option value="all">All Tasks</option>
              <option value="not started">Not Started</option>
              <option value="in progress">In Progress</option>
              <option value="completed">Completed</option>
            </Form.Select>
          </Form.Group>
        </Col>
      </Row>

      {filteredTasks.length > 0 ? (
        <Table responsive striped hover className="task-table">
          <thead>
            <tr>
              <th>Title</th>
              <th>Status</th>
              <th>Date Created</th>
              <th>Date Completed</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredTasks.map(task => (
              <TaskItem key={task._id} task={task} />
            ))}
          </tbody>
        </Table>
      ) : (
        <Card className="text-center p-4">
          <Card.Body>
            <Card.Title>No Tasks Found</Card.Title>
            <Card.Text>
              {filter !== 'all' 
                ? `No ${filter} tasks found. Try a different filter or add new tasks.`
                : 'Get started by adding your first task to this project.'}
            </Card.Text>
            <Link to={`/projects/${id}/tasks/create`}>
              <Button variant="primary">Add Task</Button>
            </Link>
          </Card.Body>
        </Card>
      )}
    </Container>
  );
};

export default ProjectDetail;