// // src/pages/WinnerList.jsx
// import React, { useEffect, useState } from 'react';
// import axios from 'axios';

// const WinnerList = () => {
//   const [winners, setWinners] = useState([]);
//   const [selectedDate, setSelectedDate] = useState("");

//   <input
//   type="date"
//   value={selectedDate}
//   onChange={(e) => setSelectedDate(e.target.value)}
//   style={{ marginLeft: "10px", padding: "8px" }}
// />

//   useEffect(() => {
//     const fetchWinners = async () => {
//       try {
//         const res = await axios.get('http://localhost:5000/api/admin/purchases');
//         const allPurchases = res.data;
//         const onlyWinners = allPurchases.filter(p => p.isWinner === true);
//         setWinners(onlyWinners);
//       } catch (err) {
//         console.error('Error fetching winners:', err);
//       }
//     };

//     fetchWinners();
//   }, []);

//   return (
//     <div className="p-5">
//       <h2 className="text-2xl font-bold mb-4">Winners List</h2>
//       {winners.length === 0 ? (
//         <p>No winners marked yet.</p>
//       ) : (
//         <table className="w-full border">
//           <thead>
//             <tr className="bg-gray-200">
//               <th className="p-2 border">Name</th>
//               <th className="p-2 border">Email</th>
//               <th className="p-2 border">Product</th>
//               <th className="p-2 border">Price</th>
//               <th className="p-2 border">Lottery No</th>
//             </tr>
//           </thead>
//           <tbody>
//             {winners.map((w, i) => (
//               <tr key={i} className="text-center">
//                 <td className="p-2 border">{w.user?.name}</td>
//                 <td className="p-2 border">{w.user?.email}</td>
//                 <td className="p-2 border">{w.productName}</td>
//                 <td className="p-2 border">₹{w.productPrice}</td>
//                 <td className="p-2 border">{w.lotteryNumber}</td>
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       )}
//     </div>
//   );
// };

// export default WinnerList;
