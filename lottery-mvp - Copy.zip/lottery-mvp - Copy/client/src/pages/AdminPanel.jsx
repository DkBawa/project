import React from "react";
import WinnerForm from "../component/WinnerForm";
import WinnerList from "../component/WinnerList"; // ✅ Import kiya

function AdminPanel() {
  return (
    <div>
      <h1>Admin Panel</h1>
      <WinnerForm />
      <hr />
      <WinnerList /> {/* ✅ Display List */}
    </div>
  );
}

export default AdminPanel;
