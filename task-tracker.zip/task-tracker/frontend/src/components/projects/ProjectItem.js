// src/components/projects/ProjectItem.js
import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { Card, Button, Badge } from 'react-bootstrap';
import PropTypes from 'prop-types';
import ProjectContext from '../../context/project/projectContext';
import TaskContext from '../../context/task/taskContext';

const ProjectItem = ({ project }) => {
  const projectContext = useContext(ProjectContext);
  const taskContext = useContext(TaskContext);

  const { deleteProject } = projectContext;
  const { tasks } = taskContext;

  const { _id, name, description, createdAt } = project;

  // Format date
  const formattedDate = new Date(createdAt).toLocaleDateString();

  // Calculate task statistics
  const projectTasks = tasks.filter(task => task.project === _id);
  const completedTasks = projectTasks.filter(task => task.status === 'Completed').length;
  const progress = projectTasks.length > 0 
    ? Math.round((completedTasks / projectTasks.length) * 100) 
    : 0;

  const onDelete = () => {
    if (window.confirm('Are you sure you want to delete this project? All associated tasks will be deleted as well.')) {
      deleteProject(_id);
    }
  };

  return (
    <Card className="project-card h-100">
      <Card.Body>
        <Card.Title>{name}</Card.Title>
        <Card.Subtitle className="mb-2 text-muted">
          Created on {formattedDate}
        </Card.Subtitle>
        <Card.Text>{description}</Card.Text>
        
        <div className="d-flex justify-content-between align-items-center mb-3">
          <span>Progress: {progress}%</span>
          <Badge bg={progress === 100 ? 'success' : progress > 0 ? 'primary' : 'secondary'}>
            {completedTasks}/{projectTasks.length} Tasks
          </Badge>
        </div>
        
        <div className="progress mb-3">
          <div 
            className={`progress-bar ${progress === 100 ? 'bg-success' : ''}`}
            role="progressbar" 
            style={{ width: `${progress}%` }} 
            aria-valuenow={progress} 
            aria-valuemin="0" 
            aria-valuemax="100"
          ></div>
        </div>
      </Card.Body>
      <Card.Footer className="bg-transparent">
        <div className="d-flex justify-content-between">
          <Link to={`/projects/${_id}`}>
            <Button variant="primary" size="sm">
              <i className="fas fa-eye"></i> View
            </Button>
          </Link>
          <div>
            <Link to={`/projects/edit/${_id}`} className="me-2">
              <Button variant="outline-secondary" size="sm">
                <i className="fas fa-edit"></i> Edit
              </Button>
            </Link>
            <Button variant="outline-danger" size="sm" onClick={onDelete}>
              <i className="fas fa-trash"></i> Delete
            </Button>
          </div>
        </div>
      </Card.Footer>
    </Card>
  );
};

ProjectItem.propTypes = {
  project: PropTypes.object.isRequired
};

export default ProjectItem;