// src/utils/setAuthToken.js
import axios from 'axios';

// Set the auth token as a default header for all axios requests if it exists
const setAuthToken = token => {
  if (token) {
    axios.defaults.headers.common['x-auth-token'] = token;
  } else {
    delete axios.defaults.headers.common['x-auth-token'];
  }
};

export default setAuthToken;