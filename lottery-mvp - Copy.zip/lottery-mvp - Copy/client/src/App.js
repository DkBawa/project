import { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Auth from './pages/Auth';
import Dashboard from './pages/Dashboard';
import LotteryProducts from './pages/LotteryProducts';
import AdminPanel from './pages/AdminPanel';
import AdminPurchases from './pages/AdminPurchases';
import WinnerList from './component/WinnerList';
import DashboardLayout from "./component/layout/DashboardLayout";

import './App.css';


function Home() {
  const [msg, setMsg] = useState('');

  useEffect(() => {
    fetch('http://localhost:5000/')
      .then(res => res.text())
      .then(data => setMsg(data));
  }, []);

  return (
    <div className="App">
      <h1>{msg}</h1>
    </div>
  );
}

function App() {
  return (
    <Router>
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<Auth/>} />
        <Route path="/auth" element={<Auth />} />

        {/* Protected/Admin Routes - wrapped in DashboardLayout */}
        <Route element={<DashboardLayout />}>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/products" element={<LotteryProducts />} />
          <Route path="/admin" element={<AdminPanel />} />
          <Route path="/admin/purchases" element={<AdminPurchases />} />
          <Route path="/admin/winners" element={<WinnerList />} />
        </Route>
      </Routes>
    </Router>
  );
}

export default App;
