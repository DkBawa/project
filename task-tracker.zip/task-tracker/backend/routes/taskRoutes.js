const protect = require('../middleware/authMiddleware');

router.get('/your-protected-route', protect, yourControllerFunction);
