// src/components/tasks/TaskItem.js
import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { Badge, Button, DropdownButton, Dropdown } from 'react-bootstrap';
import PropTypes from 'prop-types';
import TaskContext from '../../context/task/taskContext';

const TaskItem = ({ task }) => {
  const taskContext = useContext(TaskContext);
  const { updateTask, deleteTask } = taskContext;

  const { _id, title, status, createdAt, completedAt } = task;


  
  // Format dates
  const formatDate = (dateString) => {
    if (!dateString) return 'Not completed';
    return new Date(dateString).toLocaleDateString();
  };

  // Handle status change
  const handleStatusChange = (newStatus) => {
    const updatedTask = {
      ...task,
      status: newStatus,
      completedAt: newStatus === 'Completed' ? new Date() : completedAt
    };
    updateTask(updatedTask);
  };

  // Handle delete
  const onDelete = () => {
    if (window.confirm('Are you sure you want to delete this task?')) {
      deleteTask(_id);
    }
  };

  // Status badge styling
  const getBadgeVariant = (status) => {
    switch (status) {
      case 'Completed':
        return 'success';
      case 'In Progress':
        return 'warning';
      case 'Not Started':
        return 'danger';
      default:
        return 'secondary';
    }
  };

  return (
    <tr>
      <td>{title}</td>
      <td>
        <Badge bg={getBadgeVariant(status)} className="status-badge">
          {status}
        </Badge>
      </td>
      <td>{formatDate(createdAt)}</td>
      <td>{formatDate(completedAt)}</td>
      <td>
        <div className="d-flex">
          <DropdownButton 
            id={`dropdown-status-${_id}`} 
            title="Change Status" 
            size="sm" 
            variant="outline-primary"
            className="me-2"
          >
            <Dropdown.Item 
              onClick={() => handleStatusChange('Not Started')} 
              active={status === 'Not Started'}
            >
              Not Started
            </Dropdown.Item>
            <Dropdown.Item 
              onClick={() => handleStatusChange('In Progress')}
              active={status === 'In Progress'}
            >
              In Progress
            </Dropdown.Item>
            <Dropdown.Item 
              onClick={() => handleStatusChange('Completed')}
              active={status === 'Completed'}
            >
              Completed
            </Dropdown.Item>
          </DropdownButton>
          
          <Link to={`/tasks/edit/${_id}`} className="me-2">
            <Button variant="outline-secondary" size="sm">
              <i className="fas fa-edit"></i>
            </Button>
          </Link>
          
          <Button variant="outline-danger" size="sm" onClick={onDelete}>
            <i className="fas fa-trash"></i>
          </Button>
        </div>
      </td>
    </tr>
  );
};

TaskItem.propTypes = {
  task: PropTypes.object.isRequired
};

export default TaskItem;