// projectContext.js
import { createContext } from 'react';

const projectContext = createContext();

export default projectContext;