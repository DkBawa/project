// src/App.js

import { BrowserRouter as Router, Routes, Route, } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';

// Layout Components
import Navbar from './components/layout/Navbar';
import PrivateRoute from './components/routing/PrivateRoute';

// Auth Components
import Login from './components/auth/Login';
import Register from './components/auth/Register';

// Dashboard Components
import Dashboard from './components/dashboard/Dashboard';
import ProjectDetail from './components/projects/ProjectDetail';
import CreateProject from './components/projects/CreateProject';
import EditProject from './components/projects/EditProject';
import CreateTask from './components/tasks/CreateTask';
import EditTask from './components/tasks/EditTask';

// Context
import AuthState from './context/auth/AuthState';
import ProjectState from './context/project/ProjectState';
import TaskState from './context/task/TaskState';
import AlertState from './context/alert/AlertState';

// Utilities
import setAuthToken from './utils/setAuthToken';

// Check for token in localStorage
if (localStorage.token) {
  setAuthToken(localStorage.token);
}

const App = () => {
  return (
    <AuthState>
      <ProjectState>
        <TaskState>
          <AlertState>
            <Router>
              <div className="app">
                <Navbar />
                <div className="container mt-4">
                  <Routes>
                    <Route path="/login" element={<Login />} />
                    <Route path="/register" element={<Register />} />
                    <Route path="/" element={
                      <PrivateRoute>
                        <Dashboard />
                      </PrivateRoute>
                    } />
                    <Route path="/projects/:id" element={
                      <PrivateRoute>
                        <ProjectDetail />
                      </PrivateRoute>
                    } />
                    <Route path="/projects/create" element={
                      <PrivateRoute>
                        <CreateProject />
                      </PrivateRoute>
                    } />
                    <Route path="/projects/edit/:id" element={
                      <PrivateRoute>
                        <EditProject />
                      </PrivateRoute>
                    } />
                    <Route path="/projects/:projectId/tasks/create" element={
                      <PrivateRoute>
                        <CreateTask />
                      </PrivateRoute>
                    } />
                    <Route path="/tasks/edit/:id" element={
                      <PrivateRoute>
                        <EditTask />
                      </PrivateRoute>
                    } />
                  </Routes>
                </div>
              </div>
            </Router>
          </AlertState>
        </TaskState>
      </ProjectState>
    </AuthState>
  );
};

export default App;