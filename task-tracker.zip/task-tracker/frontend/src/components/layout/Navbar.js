// src/components/layout/Navbar.js
import React, { Fragment, useContext } from 'react';
import { Link } from 'react-router-dom';
import { Navbar as BootstrapNavbar, Nav, Container, Button } from 'react-bootstrap';
import AuthContext from '../../context/auth/authContext';

const Navbar = () => {
  const authContext = useContext(AuthContext);

  const { isAuthenticated, logout, user } = authContext;

  const onLogout = () => {
    logout();
  };

  const authLinks = (
    <Fragment>
      <Nav className="me-auto">
        <Nav.Link as={Link} to="/">Dashboard</Nav.Link>
      </Nav>
      <Nav>
        {user && (
          <span className="navbar-text me-3">
            <i className="fas fa-user"></i> {user.name}
          </span>
        )}
        <Button variant="outline-light" onClick={onLogout}>
          <i className="fas fa-sign-out-alt"></i> Logout
        </Button>
      </Nav>
    </Fragment>
  );

  const guestLinks = (
    <Fragment>
      <Nav className="ms-auto">
        <Nav.Link as={Link} to="/register">Register</Nav.Link>
        <Nav.Link as={Link} to="/login">Login</Nav.Link>
      </Nav>
    </Fragment>
  );

  return (
    <BootstrapNavbar bg="primary" variant="dark" expand="lg">
      <Container>
        <BootstrapNavbar.Brand as={Link} to="/">
          <i className="fas fa-tasks"></i> Task Tracker
        </BootstrapNavbar.Brand>
        <BootstrapNavbar.Toggle aria-controls="basic-navbar-nav" />
        <BootstrapNavbar.Collapse id="basic-navbar-nav">
          {isAuthenticated ? authLinks : guestLinks}
        </BootstrapNavbar.Collapse>
      </Container>
    </BootstrapNavbar>
  );
};

export default Navbar;