// TaskState.js
import React, { useReducer } from 'react';
import axios from 'axios';
import TaskContext from './taskContext';
import taskReducer from './taskReducer';

const TaskState = props => {
  const initialState = {
    tasks: [],
    task: null,
    error: null,
    loading: true
  };

  const [state, dispatch] = useReducer(taskReducer, initialState);

  // Get Tasks for a project
  const getTasks = async projectId => {
    try {
      const res = await axios.get(`/api/projects/${projectId}/tasks`);

      dispatch({
        type: 'GET_TASKS',
        payload: res.data
      });
    } catch (err) {
      dispatch({
        type: 'TASK_ERROR',
        payload: err.response.data.msg
      });
    }
  };

  // Get Task
  const getTask = async id => {
    try {
      const res = await axios.get(`/api/tasks/${id}`);

      dispatch({
        type: 'GET_TASK',
        payload: res.data
      });
    } catch (err) {
      dispatch({
        type: 'TASK_ERROR',
        payload: err.response.data.msg
      });
    }
  };

  // Add Task
  const addTask = async (projectId, task) => {
    const config = {
      headers: {
        'Content-Type': 'application/json'
      }
    };

    try {
      const res = await axios.post(
        `/api/projects/${projectId}/tasks`,
        task,
        config
      );

      dispatch({
        type: 'ADD_TASK',
        payload: res.data
      });
    } catch (err) {
      dispatch({
        type: 'TASK_ERROR',
        payload: err.response.data.msg
      });
    }
  };

  // Update Task
  const updateTask = async task => {
    const config = {
      headers: {
        'Content-Type': 'application/json'
      }
    };

    try {
      const res = await axios.put(`/api/tasks/${task._id}`, task, config);

      dispatch({
        type: 'UPDATE_TASK',
        payload: res.data
      });
    } catch (err) {
      dispatch({
        type: 'TASK_ERROR',
        payload: err.response.data.msg
      });
    }
  };

  // Delete Task
  const deleteTask = async id => {
    try {
      await axios.delete(`/api/tasks/${id}`);

      dispatch({
        type: 'DELETE_TASK',
        payload: id
      });
    } catch (err) {
      dispatch({
        type: 'TASK_ERROR',
        payload: err.response.data.msg
      });
    }
  };

  // Clear Tasks
  const clearTasks = () => {
    dispatch({ type: 'CLEAR_TASKS' });
  };

  // Clear Current Task
  const clearTask = () => {
    dispatch({ type: 'CLEAR_TASK' });
  };

  return (
    <TaskContext.Provider
      value={{
        tasks: state.tasks,
        task: state.task,
        error: state.error,
        loading: state.loading,
        getTasks,
        getTask,
        addTask,
        updateTask,
        deleteTask,
        clearTasks,
        clearTask
      }}
    >
      {props.children}
    </TaskContext.Provider>
  );
};

export default TaskState;