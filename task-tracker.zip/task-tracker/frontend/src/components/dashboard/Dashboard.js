// src/components/dashboard/Dashboard.js
import React, { useEffect, useContext } from 'react';
import { Container, Row, Col, Card, Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import ProjectContext from '../../context/project/projectContext';
import AuthContext from '../../context/auth/authContext';
import ProjectItem from '../projects/ProjectItem';
import Spinner from '../layout/Spinner';

const Dashboard = () => {
  const projectContext = useContext(ProjectContext);
  const authContext = useContext(AuthContext);

  const { projects, getProjects, loading } = projectContext;
  const { loadUser } = authContext;

  useEffect(() => {
    loadUser();
    getProjects();
    // eslint-disable-next-line
  }, []);

  return (
    <Container>
      <Row className="mb-4">
        <Col>
          <h1>
            <i className="fas fa-clipboard-list"></i> My Projects
          </h1>
          <p className="lead">Manage your projects and tasks</p>
        </Col>
        <Col xs="auto" className="align-self-center">
          {projects && projects.length < 4 ? (
            <Link to="/projects/create">
              <Button variant="primary">
                <i className="fas fa-plus"></i> New Project
              </Button>
            </Link>
          ) : (
            <Button variant="secondary" disabled title="Maximum 4 projects allowed">
              <i className="fas fa-plus"></i> New Project
            </Button>
          )}
        </Col>
      </Row>

      {loading ? (
        <Spinner />
      ) : projects && projects.length > 0 ? (
        <Row xs={1} md={2} className="g-4">
          {projects.map(project => (
            <Col key={project._id}>
              <ProjectItem project={project} />
            </Col>
          ))}
        </Row>
      ) : (
        <Card className="text-center p-5">
          <Card.Body>
            <Card.Title>No Projects Found</Card.Title>
            <Card.Text>
              Get started by creating your first project
            </Card.Text>
            <Link to="/projects/create">
              <Button variant="primary">Create Project</Button>
            </Link>
          </Card.Body>
        </Card>
      )}
    </Container>
  );
};

export default Dashboard;