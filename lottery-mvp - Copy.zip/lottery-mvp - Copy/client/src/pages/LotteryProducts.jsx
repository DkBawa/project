import { useState } from 'react';
import '../styles/ProductCard.css';
import axios from 'axios';

const products = [
  {
    id: 1,
    name: 'Healthy Diet Chart',
    price: 49,
    image: '/images/diet-chart.png',
  },
  {
    id: 2,
    name: 'UPSC Strategy Ebook',
    price: 99,
    image: '/images/upsc.png',
  },
];

export default function LotteryProducts() {
  const [loading, setLoading] = useState(false);
  const [lotteryNo, setLotteryNo] = useState('');
  const [selectedProduct, setSelectedProduct] = useState(null);

  const confirmPayment = async () => {
    console.log("🧪 confirmPayment function called");
  
    setLoading(true);
    setLotteryNo('');
  
    try {
      const token = localStorage.getItem('token');
      console.log("TOKEN BEING SENT:", token);
      console.log("PRODUCT SELECTED:", selectedProduct);
  
      const response = await axios.post('http://localhost:5000/api/lottery/buy',
        {
          productName: selectedProduct.name,
          productPrice: selectedProduct.price
        },
        {
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`
          }
        }
      );
  
      const data = response.data;
  
      if (data.lotteryNumber) {
        setLotteryNo(data.lotteryNumber);
        alert(`Ebook sent to your email!\nYour Lottery No: ${data.lotteryNumber}`);
        setSelectedProduct({name: 'Healthy Diet Chart', price: '49'}); // Reset selected product  
      } else {
        alert(data.msg || 'Something went wrong');
      }
  
    } catch (err) {
      console.error("Purchase Error:", err);
      alert(err.response?.data?.msg || 'Error during purchase.');
    } finally {
      setLoading(false);
    }
  };
  
  
  return (
    <div className="min-h-screen p-6 bg-gray-100">
      <h2 className="text-3xl font-bold text-center mb-6">🎁 Choose Your Virtual Product</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {products.map((product) => (
          <div
            key={product.id}
            className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition duration-300"
          >
            <img
              src={product.image}
              alt={product.name}
              style={{ width: '200px', height: '150px', objectFit: 'cover', borderRadius: '12px', marginBottom: '10px' }}
            />
            <br />
            <div className="p-4">
              <h3 className="text-lg font-bold mb-1">{product.name}</h3>
              <p className="text-gray-600 mb-3">₹{product.price}</p>
              <button
                onClick={() => setSelectedProduct(product)}
                className="w-full bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 transition duration-300"
              >
                Buy & Enter Lottery
              </button>
            </div>
          </div>
        ))}
      </div>

      {selectedProduct && (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex justify-center items-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-xl text-center max-w-sm w-full">
            <h2 className="text-xl font-bold mb-4">Dummy Payment</h2>
            <p className="mb-4">Pay ₹{selectedProduct.price} for <strong>{selectedProduct.name}</strong></p>
            <button
              onClick={confirmPayment}
              disabled={loading}
              className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
            >
              {loading ? 'Processing...' : 'Pay Now'}
            </button>
            <br />
            <button
              onClick={() => setSelectedProduct(null)}
              className="mt-2 text-sm text-red-500 underline"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {lotteryNo && (
        <div className="mt-6 text-center text-xl font-bold text-purple-700">
          🎉 Your Lottery Number: {lotteryNo}
        </div>
      )}
    </div>
  );
}
