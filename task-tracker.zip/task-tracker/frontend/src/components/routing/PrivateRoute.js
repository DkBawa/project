// src/components/routing/PrivateRoute.js
import React, { useContext, useEffect } from 'react';
import { Navigate } from 'react-router-dom';
import AuthContext from '../../context/auth/authContext';
import Spinner from '../layout/Spinner';

const PrivateRoute = ({ children }) => {
  const authContext = useContext(AuthContext);
  const { isAuthenticated, loading, loadUser } = authContext;

  // Load user on initial render if token exists
  useEffect(() => {
    if (localStorage.token && !isAuthenticated && !loading) {
      loadUser();
    }
    // eslint-disable-next-line
  }, []);

  if (loading) {
    return <Spinner />;
  }

  return isAuthenticated ? children : <Navigate to="/login" />;
};

export default PrivateRoute;