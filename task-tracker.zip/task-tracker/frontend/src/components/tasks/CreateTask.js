// src/components/tasks/CreateTask.js
import React, { useState, useContext, useEffect } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { Container, Card, Form, Button } from 'react-bootstrap';
import TaskContext from '../../context/task/taskContext';
import ProjectContext from '../../context/project/projectContext';
import AlertContext from '../../context/alert/alertContext';
import Spinner from '../layout/Spinner';

const CreateTask = () => {
  const taskContext = useContext(TaskContext);
  const projectContext = useContext(ProjectContext);
  const alertContext = useContext(AlertContext);
  const navigate = useNavigate();
  const { projectId } = useParams();

  const { addTask, error: taskError, clearErrors: clearTaskErrors } = taskContext;
  const { getProjectById, project, loading: projectLoading, error: projectError } = projectContext;
  const { setAlert } = alertContext;

  const [formData, setFormData] = useState({
    title: '',
    description: '',
    status: 'Not Started'
  });

  useEffect(() => {
    getProjectById(projectId);
    clearTaskErrors();
    // eslint-disable-next-line
  }, [projectId]);

  useEffect(() => {
    if (taskError) {
      setAlert(taskError, 'danger');
      clearTaskErrors();
    }

    if (projectError) {
      setAlert(projectError, 'danger');
      navigate('/');
    }
    // eslint-disable-next-line
  }, [taskError, projectError]);

  const { title, description, status } = formData;

  const onChange = e =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const onSubmit = e => {
    e.preventDefault();
    
    if (title.trim() === '') {
      setAlert('Task title is required', 'danger');
      return;
    }

    addTask({
      project: projectId,
      title,
      description,
      status
    });
    
    navigate(`/projects/${projectId}`);
  };

  if (projectLoading || !project) {
    return <Spinner />;
  }

  return (
    <Container className="mt-4">
      <Link to={`/projects/${projectId}`} className="btn btn-outline-secondary mb-3">
        <i className="fas fa-arrow-left"></i> Back to Project
      </Link>
      
      <Card className="create-task-card">
        <Card.Body>
          <h2 className="text-center mb-4">
            <i className="fas fa-plus-circle"></i> Add New Task
          </h2>
          <h5 className="text-center mb-4">Project: {project.name}</h5>
          
          <Form onSubmit={onSubmit}>
            <Form.Group className="mb-3">
              <Form.Label>Task Title*</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter task title"
                name="title"
                value={title}
                onChange={onChange}
                required
              />
            </Form.Group>
            
            <Form.Group className="mb-3">
              <Form.Label>Description</Form.Label>
              <Form.Control
                as="textarea"
                rows={4}
                placeholder="Enter task description"
                name="description"
                value={description}
                onChange={onChange}
              />
            </Form.Group>
            
            <Form.Group className="mb-3">
              <Form.Label>Status</Form.Label>
              <Form.Select
                name="status"
                value={status}
                onChange={onChange}
              >
                <option value="Not Started">Not Started</option>
                <option value="In Progress">In Progress</option>
                <option value="Completed">Completed</option>
              </Form.Select>
            </Form.Group>
            
            <div className="d-grid gap-2">
              <Button variant="primary" type="submit">
                Add Task
              </Button>
              <Button variant="outline-secondary" as={Link} to={`/projects/${projectId}`}>
                Cancel
              </Button>
            </div>
          </Form>
        </Card.Body>
      </Card>
    </Container>
  );
};

export default CreateTask;