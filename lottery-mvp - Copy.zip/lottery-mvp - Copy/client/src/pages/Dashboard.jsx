// Dashboard.jsx

import React from 'react';

const Dashboard = () => {
  return (
    <div className="container">
      <h2 className="my-4">Admin Dashboard Overview</h2>

      {/* Overview Cards */}
      <div className="row">
        <div className="col-md-4">
          <div className="card text-white bg-primary mb-3">
            <div className="card-body">
              <h5 className="card-title">Total Products</h5>
              <p className="card-text">25</p>
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card text-white bg-success mb-3">
            <div className="card-body">
              <h5 className="card-title">Total Purchases</h5>
              <p className="card-text">120</p>
            </div>
          </div>
        </div>

        <div className="col-md-4">
          <div className="card text-white bg-warning mb-3">
            <div className="card-body">
              <h5 className="card-title">Total Winners</h5>
              <p className="card-text">10</p>
            </div>
          </div>
        </div>
      </div>
    {/* Recent Winners Table */}
      <div className="card mt-5">
  <div className="card-header bg-dark text-white">
    Recent Winners
  </div>
  <div className="card-body">
    <table className="table table-bordered table-striped">
      <thead className="table-dark">
        <tr>
          <th>#</th>
          <th>Name</th>
          <th>Email</th>
          <th>Lottery Number</th>
          <th>Date</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>1</td>
          <td>Ravi Kumar</td>
          <td>ravi@example.com</td>
          <td>#LOTT2024-001</td>
          <td>2025-04-10</td>
        </tr>
        <tr>
          <td>2</td>
          <td>Priya Mehta</td>
          <td>priya@example.com</td>
          <td>#LOTT2024-002</td>
          <td>2025-04-09</td>
        </tr>
      </tbody>
    </table>
  </div>
</div>
 </div>
  )};

export default Dashboard;
