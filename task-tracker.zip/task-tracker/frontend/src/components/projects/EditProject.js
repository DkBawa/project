// src/components/projects/EditProject.js
import React, { useState, useContext, useEffect } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { Container, Card, Form, Button } from 'react-bootstrap';
import ProjectContext from '../../context/project/projectContext';
import AlertContext from '../../context/alert/alertContext';
import Spinner from '../layout/Spinner';

const EditProject = () => {
  const projectContext = useContext(ProjectContext);
  const alertContext = useContext(AlertContext);
  const navigate = useNavigate();
  const { id } = useParams();

  const { getProjectById, project, updateProject, error, clearErrors, loading } = projectContext;
  const { setAlert } = alertContext;

  const [formData, setFormData] = useState({
    name: '',
    description: ''
  });

  useEffect(() => {
    getProjectById(id);
    clearErrors();
    // eslint-disable-next-line
  }, [id]);

  useEffect(() => {
    if (project) {
      setFormData({
        name: project.name || '',
        description: project.description || ''
      });
    }

    if (error) {
      setAlert(error, 'danger');
      clearErrors();
    }
    // eslint-disable-next-line
  }, [project, error]);

  const { name, description } = formData;

  const onChange = e =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const onSubmit = e => {
    e.preventDefault();
    
    if (name.trim() === '') {
      setAlert('Project name is required', 'danger');
      return;
    }

    updateProject({
      _id: id,
      name,
      description
    });
    
    navigate(`/projects/${id}`);
  };

  if (loading || !project) {
    return <Spinner />;
  }

  return (
    <Container className="mt-4">
      <Link to={`/projects/${id}`} className="btn btn-outline-secondary mb-3">
        <i className="fas fa-arrow-left"></i> Back to Project
      </Link>
      
      <Card className="edit-project-card">
        <Card.Body>
          <h2 className="text-center mb-4">
            <i className="fas fa-edit"></i> Edit Project
          </h2>
          
          <Form onSubmit={onSubmit}>
            <Form.Group className="mb-3">
              <Form.Label>Project Name*</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter project name"
                name="name"
                value={name}
                onChange={onChange}
                required
              />
            </Form.Group>
            
            <Form.Group className="mb-3">
              <Form.Label>Description</Form.Label>
              <Form.Control
                as="textarea"
                rows={4}
                placeholder="Enter project description"
                name="description"
                value={description}
                onChange={onChange}
              />
            </Form.Group>
            
            <div className="d-grid gap-2">
              <Button variant="primary" type="submit">
                Update Project
              </Button>
              <Button variant="outline-secondary" as={Link} to={`/projects/${id}`}>
                Cancel
              </Button>
            </div>
          </Form>
        </Card.Body>
      </Card>
    </Container>
  );
};

export default EditProject;