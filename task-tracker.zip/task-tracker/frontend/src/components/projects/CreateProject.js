// src/components/projects/CreateProject.js
import React, { useState, useContext, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Container, Card, Form, Button,} from 'react-bootstrap';
import ProjectContext from '../../context/project/projectContext';
import AlertContext from '../../context/alert/alertContext';

const CreateProject = () => {
  const projectContext = useContext(ProjectContext);
  const alertContext = useContext(AlertContext);
  const navigate = useNavigate();

  const { addProject, error, clearErrors, projects } = projectContext;
  const { setAlert } = alertContext;

  // Check if user has reached max projects
  useEffect(() => {
    if (projects && projects.length >= 4) {
      setAlert('Maximum limit of 4 projects reached', 'danger');
      navigate('/');
    }

    if (error) {
      setAlert(error, 'danger');
      clearErrors();
    }
    // eslint-disable-next-line
  }, [error, projects]);

  const [formData, setFormData] = useState({
    name: '',
    description: ''
  });

  const { name, description } = formData;

  const onChange = e =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const onSubmit = e => {
    e.preventDefault();
    
    if (name.trim() === '') {
      setAlert('Project name is required', 'danger');
      return;
    }

    addProject(formData);
    navigate('/');
  };

  return (
    <Container className="mt-4">
      <Link to="/" className="btn btn-outline-secondary mb-3">
        <i className="fas fa-arrow-left"></i> Back to Dashboard
      </Link>
      
      <Card className="create-project-card">
        <Card.Body>
          <h2 className="text-center mb-4">
            <i className="fas fa-folder-plus"></i> Create New Project
          </h2>
          
          <Form onSubmit={onSubmit}>
            <Form.Group className="mb-3">
              <Form.Label>Project Name*</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter project name"
                name="name"
                value={name}
                onChange={onChange}
                required
              />
            </Form.Group>
            
            <Form.Group className="mb-3">
              <Form.Label>Description</Form.Label>
              <Form.Control
                as="textarea"
                rows={4}
                placeholder="Enter project description"
                name="description"
                value={description}
                onChange={onChange}
              />
            </Form.Group>
            
            <div className="d-grid gap-2">
              <Button variant="primary" type="submit">
                Create Project
              </Button>
              <Button variant="outline-secondary" as={Link} to="/">
                Cancel
              </Button>
            </div>
          </Form>
        </Card.Body>
      </Card>
    </Container>
  );
};

export default CreateProject;