
// ProjectState.js
import React, { useReducer } from 'react';
import axios from 'axios';
import ProjectContext from './projectContext';
import projectReducer from './projectReducer';

const ProjectState = props => {
  const initialState = {
    projects: [],
    project: null,
    error: null,
    loading: true
  };

  const [state, dispatch] = useReducer(projectReducer, initialState);

  // Get Projects
  const getProjects = async () => {
    try {
      const res = await axios.get('/api/projects');

      dispatch({
        type: 'GET_PROJECTS',
        payload: res.data
      });
    } catch (err) {
      dispatch({
        type: 'PROJECT_ERROR',
        payload: err.response.data.msg
      });
    }
  };

  // Get Project
  const getProject = async id => {
    try {
      const res = await axios.get(`/api/projects/${id}`);

      dispatch({
        type: 'GET_PROJECT',
        payload: res.data
      });
    } catch (err) {
      dispatch({
        type: 'PROJECT_ERROR',
        payload: err.response.data.msg
      });
    }
  };

  // Add Project
  const addProject = async project => {
    const config = {
      headers: {
        'Content-Type': 'application/json'
      }
    };

    try {
      const res = await axios.post('/api/projects', project, config);

      dispatch({
        type: 'ADD_PROJECT',
        payload: res.data
      });
    } catch (err) {
      dispatch({
        type: 'PROJECT_ERROR',
        payload: err.response.data.msg
      });
    }
  };

  // Update Project
  const updateProject = async project => {
    const config = {
      headers: {
        'Content-Type': 'application/json'
      }
    };

    try {
      const res = await axios.put(
        `/api/projects/${project._id}`,
        project,
        config
      );

      dispatch({
        type: 'UPDATE_PROJECT',
        payload: res.data
      });
    } catch (err) {
      dispatch({
        type: 'PROJECT_ERROR',
        payload: err.response.data.msg
      });
    }
  };

  // Delete Project
  const deleteProject = async id => {
    try {
      await axios.delete(`/api/projects/${id}`);

      dispatch({
        type: 'DELETE_PROJECT',
        payload: id
      });
    } catch (err) {
      dispatch({
        type: 'PROJECT_ERROR',
        payload: err.response.data.msg
      });
    }
  };

  // Clear Project
  const clearProject = () => {
    dispatch({ type: 'CLEAR_PROJECT' });
  };

  return (
    <ProjectContext.Provider
      value={{
        projects: state.projects,
        project: state.project,
        error: state.error,
        loading: state.loading,
        getProjects,
        getProject,
        addProject,
        updateProject,
        deleteProject,
        clearProject
      }}
    >
      {props.children}
    </ProjectContext.Provider>
  );
};

export default ProjectState;
